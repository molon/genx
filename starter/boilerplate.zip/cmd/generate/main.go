package main

//go:generate go run .

import (
	"context"
	"log"

	gqlapi "github.com/99designs/gqlgen/api"
	gqlconfig "github.com/99designs/gqlgen/codegen/config"
	"github.com/molon/genx"
	"github.com/molon/genx/extension/gosurgery"
	"github.com/molon/genx/extension/relayext"
	"github.com/pkg/errors"
)

func main() {
	if err := Generate(context.Background()); err != nil {
		log.Fatalf("failed to generate: %+v", err)
	}
}

func Generate(ctx context.Context) error {
	if err := genx.Generate(ctx, &genx.Config{
		OutputDir:           "../../",
		PrototypeRelPattern: "prototype.graphql",
		GoModule:            "github.com/molon/genx/starter/boilerplate",
		Extensions: []genx.Extension{
			relayext.New(),
			gosurgery.New(),
		},
	}); err != nil {
		return errors.Wrap(err, "failed to generate")
	}

	gqlconf, err := gqlconfig.LoadConfigFromDefaultLocations()
	if err != nil {
		return errors.Wrap(err, "failed to load gqlgen config")
	}

	if err := gqlapi.Generate(gqlconf); err != nil {
		return errors.Wrap(err, "failed to generate gqlgen")
	}

	return nil
}
