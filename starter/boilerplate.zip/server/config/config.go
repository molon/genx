package config

import (
	_ "embed"
	"strings"
	"time"

	"github.com/molon/genx/pkg/configx"
	"github.com/pkg/errors"
	"github.com/spf13/pflag"
)

type DatabaseConfig struct {
	DSN             string        `mapstructure:"dsn"`
	Debug           bool          `mapstructure:"debug"`
	MaxIdleConns    int           `mapstructure:"maxIdleConns"`
	MaxOpenConns    int           `mapstructure:"maxOpenConns"`
	ConnMaxLifetime time.Duration `mapstructure:"connMaxLifetime"`
	ConnMaxIdleTime time.Duration `mapstructure:"connMaxIdleTime"`
}

type ServerConfig struct {
	HTTPAddress        string `mapstructure:"httpAddress"`
	GraphQLEndpoint    string `mapstructure:"graphqlEndpoint"`
	PlaygroundEndpoint string `mapstructure:"playgroundEndpoint"`
}

type Config struct {
	Database DatabaseConfig `mapstructure:"database"`
	Server   ServerConfig   `mapstructure:"server"`
}

//go:embed embed/default.yaml
var defaultConfigYAML string

func Initialize(flagSet *pflag.FlagSet, envPrefix string) (configx.Loader[*Config], error) {
	def, err := configx.Read[*Config]("yaml", strings.NewReader(defaultConfigYAML))
	if err != nil {
		return nil, errors.Wrap(err, "failed to load default config from embedded YAML")
	}
	return configx.Initialize(flagSet, envPrefix, def)
}
